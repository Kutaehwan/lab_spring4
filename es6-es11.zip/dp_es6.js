{
  function print(msg) {
    if (msg == null) {
      msg = 'default message';
    }
    console.log(msg);
  }
  print('hello');
  // print();
}